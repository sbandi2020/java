package com.test.tipadwiser.home;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.*;
import org.testng.annotations.*;
import org.testng.asserts.*;


public class HomePage {

	WebDriver driver;
	//*[@title="Search"]
	By serachLocator = By.xpath("//*[@title='Search']");
	By mainSearchLocator = By.xpath("//input[@id='mainSearch']");
	By autoComplete = By.xpath("//li[@class='displayItem result']");
	By reviewsTab = By.xpath("//*[@id='component_12']/div/div[2]/div/div[2]/div/div[1]/a");
	By ratingTab =  By.id("bubble_rating");
	By ratingStar = By.xpath("//span[@class='ui_bubble_rating fl bubble_50']");
	By reviewTitle = By.id("ReviewTitle");
	By reviewText = By.id("ReviewText");
	By serviceRating = By.id("qid12_bubbles");
	By sleepQualityRating = By.id("qid190_bubbles");
	By cleanlinesRating = By.id("qid14_bubbles");
	
	public void locateSearchBox(WebDriver driver,String searchUrl){
		this.driver = driver;
		driver.get(searchUrl);
		driver.manage().window().maximize();
		driver.findElement(serachLocator).click();
	}
	
	public void locateMainSearchBox(WebDriver driver, String searchString){
		this.driver = driver;
		driver.findElement(mainSearchLocator).sendKeys(searchString);
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		driver.findElement(autoComplete).click();
		
	}
	
	public void selectReviewsTab(WebDriver driver){
		this.driver = driver;
		try{
		driver.findElement(reviewsTab).click();
		}
		catch(Exception ex){
			driver.findElement(reviewsTab).click();
		}
		
		Set<String> windowsSet = driver.getWindowHandles(); 
		Iterator windows = windowsSet.iterator();
		String nextWindow = "";
		while(windows.hasNext()){
			nextWindow = (String)windows.next();
		}
		driver.switchTo().window(nextWindow);
		String url = driver.getCurrentUrl();
		System.out.println(url);
		driver.findElement(ratingTab).click();
		
		WebElement ratingElement = driver.findElement(By.xpath("//*[@id='bubble_rating']"));
		Actions action = new Actions(driver); 
		action.moveToElement(ratingElement).click(ratingElement).build().perform();
        action.moveByOffset(50, 0).click().build().perform(); 
	}
	
}
