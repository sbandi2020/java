package com.test.tipadwiser.review;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.*;
import org.testng.annotations.*;
import org.testng.asserts.*;

public class ReviewPage {


	WebDriver driver;
	
	By ratingTab =  By.id("bubble_rating");
	By ratingStar = By.xpath("//span[@class='ui_bubble_rating fl bubble_50']");
	By reviewTitle = By.id("ReviewTitle");
	By reviewText = By.id("ReviewText");
	By serviceRating = By.id("qid12_bubbles");
	By sleepQualityRating = By.id("qid190_bubbles");
	By cleanlinesRating = By.id("qid14_bubbles");
			
	public void reviwComments(WebDriver driver, String title, String text){
		driver.findElement(reviewTitle).sendKeys(title);
		driver.findElement(reviewText).sendKeys(text);
	}
	
	public void performHotelRating(WebDriver driver){
		WebElement service = driver.findElement(serviceRating);
		WebElement sleepQuality = driver.findElement(sleepQualityRating);
		WebElement cleanlines = driver.findElement(cleanlinesRating);
		
		Actions action = new Actions(driver); 
		//service rating
		action.moveToElement(service).click(service).build().perform();
        action.moveByOffset(50, 0).click().build().perform();
        
       //sleep quality rating
        action.moveToElement(sleepQuality).click(sleepQuality).build().perform();
        action.moveByOffset(40, 0).click().build().perform();
        
       //cleanliness rating
        action.moveToElement(cleanlines).click(cleanlines).build().perform();
        action.moveByOffset(40, 0).click().build().perform();
	}
	
	
}
