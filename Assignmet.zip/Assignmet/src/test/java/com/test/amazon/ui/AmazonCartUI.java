package com.test.amazon.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.*;
import org.testng.annotations.*;

public class AmazonCartUI {
	
	WebDriver driver;
	By search1 = By.id("twotabsearchtextbox");
	By submit =  By.className("nav-input");
	By priceElement = By.xpath("//*[@id='search']/div[1]/div[2]/div/span[4]/div[1]/div[1]/div/span/div/div/div/div/div[2]/div[2]/div/div[2]/div[1]/div/div[1]/div/div/a/span[1]/span[2]/span[2]");
	
	
	public void searchPhone(WebDriver driver,String searchUrl){
	 this.driver = driver;
	 driver.get(searchUrl);
	 driver.manage().window().maximize();
	 driver.findElement(search1).sendKeys("iphone xr 64GB yellow");
	
	}
	
	public void submitSearch(WebDriver driver){
		this.driver = driver;
		driver.findElement(submit).submit();
	}
	
	public double getphonePrice(WebDriver driver){
		String price = driver.findElement(priceElement).getText();
		System.out.println(price);
		String actualPrice = price.substring(0,2) + price.substring(3,6);
		System.out.println(actualPrice);
		double dPrice = Double.parseDouble(actualPrice);
		return dPrice;
	}
	
   
	

}
