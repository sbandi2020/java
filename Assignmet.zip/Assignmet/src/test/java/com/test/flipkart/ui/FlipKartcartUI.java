package com.test.flipkart.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.*;
import org.testng.annotations.*;

public class FlipKartcartUI {
	
	WebDriver driver;
	By searchLocatot =  By.className("LM6RPg");
	By submitLocator =  By.className("vh79eN");
	By priceLocator =   By.xpath(".//*[@class='_1vC4OE _2rQ-NK']");
	
	
	public void searchPhone(WebDriver driver, String searchURL){
	 this.driver = driver;
	 driver.get(searchURL);
	 
	 WebElement cancelButton = driver.findElement((By.xpath("/html/body/div[2]/div/div/button")));
	 cancelButton.click();
	 driver.findElement(searchLocatot).sendKeys("phone xr 64GB yellow");
	
	}
	
	public void submitSearch(WebDriver driver){
		this.driver = driver;
		driver.findElement(submitLocator).click();
	}
	
	public double getphonePrice(WebDriver driver){
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		String price = driver.findElement(priceLocator).getText();
		String actualPrice = price.substring(1,3) + price.substring(4,7);
		System.out.println(actualPrice);
		double dPrice = Double.parseDouble(actualPrice);
		return dPrice;
	}
	

}
