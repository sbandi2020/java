package com.test1;

import com.test.amazon.ui.AmazonCartUI;
import com.test.flipkart.ui.FlipKartcartUI;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.*;
import org.testng.annotations.*;
import org.testng.asserts.*;

public class Test1 {
	
	WebDriver driver;
	@BeforeTest
	public void driverSetup(){
	  System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\src\\test\\java\\drivers\\chromedriver.exe");
	  driver = new ChromeDriver();
	}
	
	@Test
	public void compareMobilePrices(){
		
		String searchUrl = "https://www.amazon.in";
		AmazonCartUI amazonUI = new AmazonCartUI();
		
		amazonUI.searchPhone(driver, searchUrl);
		amazonUI.submitSearch(driver);
		double amazonPrice = amazonUI.getphonePrice(driver);
		
		searchUrl = "https://www.flipKart.com";
		FlipKartcartUI flipKartUI = new FlipKartcartUI();
		flipKartUI.searchPhone(driver, searchUrl);
		flipKartUI.submitSearch(driver);
		double flipKartPrice = flipKartUI.getphonePrice(driver);
		
		System.out.println("amazonPrice: " + amazonPrice);
		System.out.println("flipKartPrice: " + flipKartPrice);
		
		boolean amazonLowPriceFlag;
		if(amazonPrice < flipKartPrice){
			amazonLowPriceFlag = true;
		}	
		else{
			amazonLowPriceFlag = false;
			
		}
		
		Assert.assertTrue(amazonLowPriceFlag,"Amazon offers lowest price than flipKart");
		
		
					
	}
		
	@AfterTest
	public void closeDriver(){
		driver.close();
	}
 
}
