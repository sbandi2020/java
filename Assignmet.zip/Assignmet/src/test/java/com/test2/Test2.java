package com.test2;

import com.test.tipadwiser.home.HomePage;
import com.test.tipadwiser.review.ReviewPage;

import com.test.amazon.ui.AmazonCartUI;
import com.test.flipkart.ui.FlipKartcartUI;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.*;
import org.testng.annotations.*;
import org.testng.asserts.*;

public class Test2 {

	@Test
	public void test1()
	{
	 System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\src\\test\\java\\drivers\\chromedriver.exe"); 
	 WebDriver driver = new ChromeDriver();
	 String siteUrl = "https://www.tripadvisor.in/";
	 
	 HomePage homePage = new HomePage();
	 ReviewPage reviewPage = new ReviewPage();
	 
	 homePage.locateSearchBox(driver,  siteUrl);
	 String searchString = "ClubMahindra";
	 homePage.locateMainSearchBox(driver,  searchString);
	 homePage.selectReviewsTab(driver);
	 
	 String reviewTitle = "Service Review";
	 String reviewText = "Service is Excellent and all rooms are as good as expected";
	 reviewPage.reviwComments(driver, reviewTitle, reviewText);
	 
	 reviewPage.performHotelRating(driver);
	  
	
	}
}
